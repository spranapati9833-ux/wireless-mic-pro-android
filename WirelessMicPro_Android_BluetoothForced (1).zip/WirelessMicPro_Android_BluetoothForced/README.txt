WIRELESS MIC PRO - ANDROID NATIVE PROJECT

Goal:
- Native mic loopback.
- Uses AudioTrack with USAGE_MEDIA.
- Does NOT force MODE_IN_COMMUNICATION or Bluetooth SCO.
- This is designed so the microphone voice follows the phone's normal media output,
  including a Bluetooth speaker selected as Media Output.
- YouTube can be opened while the native mic loopback continues running.

IMPORTANT:
This folder is an Android Studio project source. It is not a precompiled APK.
To build:
1. Open folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install app-debug.apk on Android.
5. Connect Bluetooth speaker and select it as Media Output before starting MIC.

Why not a compiled APK here:
The current execution environment does not have the Android SDK/Gradle toolchain installed,
so it cannot produce a signed/installable APK directly.

BLUETOOTH-FORCED UPDATE:
- Added ROUTE MIC TO BLUETOOTH button.
- Finds A2DP / BLE speaker output.
- Calls AudioTrack.setPreferredDevice() to force the mic monitor toward the connected Bluetooth media device.
- Still avoids MODE_IN_COMMUNICATION and Bluetooth SCO so YouTube/music is less likely to be stopped.

Use:
1. Connect Bluetooth speaker in Android and enable Media Audio.
2. Open app.
3. Tap ROUTE MIC TO BLUETOOTH.
4. Confirm screen says Bluetooth ready/forced.
5. Start YouTube music.
6. Turn MIC ON.
