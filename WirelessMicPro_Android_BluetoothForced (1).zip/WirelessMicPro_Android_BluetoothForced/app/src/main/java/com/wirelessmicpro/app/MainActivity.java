package com.wirelessmicpro.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_MIC = 1001;
    private static final int REQ_BT = 1002;
    private Button micButton;
    private TextView micStatus, outputStatus, volumeLabel;
    private SeekBar micVolume;

    private volatile boolean running = false;
    private Thread audioThread;
    private AudioRecord recorder;
    private AudioTrack player;
    private AudioDeviceInfo preferredBluetoothOutput;
    private float volume = 0.90f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        micButton = findViewById(R.id.micButton);
        micStatus = findViewById(R.id.micStatus);
        outputStatus = findViewById(R.id.outputStatus);
        micVolume = findViewById(R.id.micVolume);
        volumeLabel = findViewById(R.id.volumeLabel);
        Button youtubeButton = findViewById(R.id.youtubeButton);
        Button routeButton = findViewById(R.id.routeButton);

        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);

        // Critical: keep NORMAL mode. Do NOT use MODE_IN_COMMUNICATION / Bluetooth SCO.
        am.setMode(AudioManager.MODE_NORMAL);


        routeButton.setOnClickListener(v -> {
            AudioManager mgr = (AudioManager) getSystemService(AUDIO_SERVICE);
            preferredBluetoothOutput = findBluetoothOutput(mgr);
            if (preferredBluetoothOutput != null) {
                if (player != null) {
                    boolean ok = player.setPreferredDevice(preferredBluetoothOutput);
                    outputStatus.setText(ok
                            ? "Output: Bluetooth forced — " + preferredBluetoothOutput.getProductName()
                            : "Bluetooth found, but Android refused direct route");
                } else {
                    outputStatus.setText("Bluetooth ready — turn MIC ON");
                }
            } else {
                outputStatus.setText("Bluetooth speaker not found. Connect it as Media Audio first.");
            }
        });

        micButton.setOnClickListener(v -> {
            if (running) {
                stopMic();
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                } else {
                    startMic();
                }
            }
        });

        micVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                volume = Math.max(0f, Math.min(1.5f, progress / 100f));
                volumeLabel.setText("Mic Volume: " + progress + "%");
                if (player != null) {
                    try { player.setVolume(volume); } catch (Exception ignored) {}
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        youtubeButton.setOnClickListener(v -> {
            // Opens YouTube in browser/app. Mic loopback keeps running because it is native.
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.youtube.com"));
                startActivity(i);
            } catch (Exception e) {
                micStatus.setText("Could not open YouTube.");
            }
        });

        updateOutputText(am);
    }


    private AudioDeviceInfo findBluetoothOutput(AudioManager am) {
        AudioDeviceInfo[] outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        for (AudioDeviceInfo d : outs) {
            int t = d.getType();
            if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) return d;
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                if (t == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                    t == AudioDeviceInfo.TYPE_BLE_HEADSET) return d;
            }
        }
        return null;
    }

    private void updateOutputText(AudioManager am) {
        StringBuilder sb = new StringBuilder("Output: ");
        AudioDeviceInfo[] outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS);
        boolean bluetooth = false;
        for (AudioDeviceInfo d : outs) {
            int t = d.getType();
            if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                t == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                t == AudioDeviceInfo.TYPE_BLE_HEADSET) {
                bluetooth = true;
                break;
            }
        }
        preferredBluetoothOutput = findBluetoothOutput(am);
        sb.append(bluetooth ? "Bluetooth available — tap ROUTE MIC TO BLUETOOTH" : "System Media output");
        outputStatus.setText(sb.toString());
    }

    private void startMic() {
        final int sampleRate = 48000;
        final int channelIn = AudioFormat.CHANNEL_IN_MONO;
        final int encoding = AudioFormat.ENCODING_PCM_16BIT;

        int minRec = AudioRecord.getMinBufferSize(sampleRate, channelIn, encoding);
        int minPlay = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, encoding);
        final int bufferSize = Math.max(Math.max(minRec, minPlay), 4096) * 2;

        AudioFormat recordFormat = new AudioFormat.Builder()
                .setEncoding(encoding)
                .setSampleRate(sampleRate)
                .setChannelMask(channelIn)
                .build();

        AudioFormat playFormat = new AudioFormat.Builder()
                .setEncoding(encoding)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build();

        try {
            recorder = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                    .setAudioFormat(recordFormat)
                    .setBufferSizeInBytes(bufferSize)
                    .build();

            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();

            player = new AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(playFormat)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(bufferSize)
                    .build();

            player.setVolume(volume);

            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            preferredBluetoothOutput = findBluetoothOutput(am);
            if (preferredBluetoothOutput != null) {
                boolean routed = player.setPreferredDevice(preferredBluetoothOutput);
                final String routeText = routed
                        ? "Output: Bluetooth forced — " + preferredBluetoothOutput.getProductName()
                        : "Bluetooth found, Android routing fallback active";
                runOnUiThread(() -> outputStatus.setText(routeText));
            }

            recorder.startRecording();
            player.play();

            running = true;
            micButton.setText("🎙 MIC ON");
            micStatus.setText("Live mic active — playing on MEDIA output");

            audioThread = new Thread(() -> {
                short[] buf = new short[bufferSize / 2];
                while (running) {
                    int n = recorder.read(buf, 0, buf.length, AudioRecord.READ_BLOCKING);
                    if (n > 0 && running) {
                        // Soft near-voice gate + clipping protection.
                        long sum = 0;
                        for (int i = 0; i < n; i++) {
                            int s = buf[i];
                            sum += (long)s * s;
                        }
                        double rms = Math.sqrt(sum / (double)Math.max(1, n)) / 32768.0;
                        float gate = rms < 0.018 ? 0.08f : 1.0f;

                        if (gate != 1.0f) {
                            for (int i = 0; i < n; i++) {
                                buf[i] = (short)(buf[i] * gate);
                            }
                        }

                        player.write(buf, 0, n, AudioTrack.WRITE_BLOCKING);
                    }
                }
            }, "MicLoopThread");
            audioThread.start();

        } catch (Exception e) {
            micStatus.setText("Mic error: " + e.getMessage());
            stopMic();
        }
    }

    private void stopMic() {
        running = false;

        if (audioThread != null) {
            try { audioThread.interrupt(); } catch (Exception ignored) {}
            audioThread = null;
        }
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) {}
            try { recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }

        if (micButton != null) micButton.setText("🎙 MIC OFF");
        if (micStatus != null) micStatus.setText("Mic is off");
    }

    @Override
    protected void onDestroy() {
        stopMic();
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startMic();
        } else {
            micStatus.setText("Microphone permission required.");
        }
    }
}